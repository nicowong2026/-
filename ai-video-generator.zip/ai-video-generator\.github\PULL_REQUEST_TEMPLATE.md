## Summary

<!-- What does this PR do? Why is it needed? -->

## Changes

- [ ] New feature
- [ ] Bug fix
- [ ] Refactoring
- [ ] Documentation
- [ ] CI / tooling

## Description

<!-- Provide a clear and concise description of the changes. -->

## Related Issues

<!-- Link related issues: "Closes #123", "Fixes #456" -->

## Testing

<!-- Describe how the changes were tested. -->

```bash
pytest tests/ -v
```

## Checklist

- [ ] Tests pass locally (`pytest tests/`)
- [ ] No linting errors (`ruff check src/`)
- [ ] Type checks pass (`mypy src/`)
- [ ] Documentation updated (if applicable)
- [ ] `CHANGELOG.md` entry added under `[Unreleased]`
- [ ] Self-reviewed the diff

## Screenshots / Output (if applicable)

<!-- Add any relevant output, screenshots, or generated video examples. -->
